jQuery.sap.declare("sap.openSAP.smarttableProducts.Component");

sap.ui.core.UIComponent.extend("sap.openSAP.smarttableProducts.Component", {

	metadata: {
		manifest: "json",

		dependencies: {
			libs: [
				"sap.m", "sap.ui.comp"
			]
		}
	}
});

